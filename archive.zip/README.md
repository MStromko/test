//JAKUB RASKOVSKY dokumentacia k hre 

Moja hra je postapokalipticky svet v ktorom predtym zili vsetci v harmonii a
mieri. No aj v tomto svete sa nasiel niekto kto chcel vsetko to najlepsie
len pre seba a ma pstatnych sa nepozeral,preto skusal rozne veci vo svojom
laboratoriu aby mal vsetko pre seba a uz nikdy mu nikto nehovoril, ze je
odlisny a ze nezapada. Ty ako Hrac si bol na planete mars, kde sa uz ludia
mali ist ubytovat a prisiel si na zem doniest skvelu spravu no ako si sa 
vratili na zem, videl si len zdevastovanu zem par stien a vela nepriatelskych
monstier, casom si zistil, ze su imunne voci minam ktore si nasiel len
vdaka jednej vyhrabanej na ktoru si skoro sliapol. Rozhodol si sa utaborit
pri doloch ktore si objavil a su ohradene stenami takze myslis ze je tam
bezpecie a nikto ta tam nevyrusi. Ale je to naozaj tak?

Cielom hry je sa pripravit na nepriatelske monstra zabit ich a zistit, ze si zostal uplne sam a ten zivot nema zmysel. 

Kra sa prelozi pomocou prikazu make a spusti sa pomocou prikazu ./game

Koniec hry nastava vtedy ak su vsetky monstra zabite alebo ak sliapnes na minu



pouzite zdrojeve kody
https://github.com/hladek/world
